etcd_common
========================

TODO

Requirements
------------

TODO

Role Variables
--------------

TODO

Dependencies
------------

openshift-repos

Example Playbook
----------------

TODO

License
-------

Apache License Version 2.0

Author Information
------------------

Jason DeTiberus (jdetiber@redhat.com)
