Image Streams and Templates may require specific versions of OpenShift so
they've been namespaced. At this time, once a new version of Origin is released
the older versions will only receive new content by speficic request.

Please file an issue at https://github.com/openshift/openshift-ansible if you'd
like to see older content updated and have tested to ensure it's backwards
compatible.
