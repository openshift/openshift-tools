[provide a description of the issue]

##### Version
[if you're operating from a git clone provide the output of `git describe`]
[if you're running from playbooks installed via RPM or atomic-openshift-utils `rpm -q atomic-openshift-utils openshift-ansible`]
[Your version of ansible, `ansible --version`]


##### Steps To Reproduce
1. [step 1]
2. [step 2]

##### Current Result

##### Expected Result

##### Additional Information
[The exact command you ran]
[Your operating system and version, ie: RHEL 7.2, Fedora 23]
[Your inventory file]
[visit https://docs.openshift.org/latest/welcome/index.html]
