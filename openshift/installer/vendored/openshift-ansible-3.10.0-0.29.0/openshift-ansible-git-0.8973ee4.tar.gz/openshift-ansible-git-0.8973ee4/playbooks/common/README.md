# Common playbooks

This directory has a generic set of playbooks that are included by playbooks in
[`byo`](../byo).

Note: playbooks in this directory use generic group names that do not line up
with the groups used by the `byo` playbooks, requiring an explicit remapping of
groups.
