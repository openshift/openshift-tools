# OpenShift Monitoring

This playbook runs the [Cluster Monitoring Operator role](../../roles/openshift_cluster_monitoring_operator). See the role
for more information.

## GCP Development

The `install-gcp.yml` playbook is useful for ad-hoc installation in an existing GCE cluster.
