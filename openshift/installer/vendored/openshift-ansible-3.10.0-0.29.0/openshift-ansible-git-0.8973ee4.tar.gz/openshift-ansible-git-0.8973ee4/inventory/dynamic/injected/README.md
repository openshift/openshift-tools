This directory may be used to inject inventory into openshift-ansible
when used in a container. Other scripts like the cloud provider entrypoints
will automatically use the content of this directory as inventory.
